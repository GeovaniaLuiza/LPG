/**2.Fa�a um programa em C com uma fun��o para calcular a m�dia de 4
valores (par�metros) e retorne o resultado ao programa principal. **/

#include <stdio.h>

float Media (float a, float b, float c, float d);

int main () {
float num1, num2, num3, num4;
float media;
printf ("Entre com o primeiro numero: ");
scanf ("%f",&num1);
printf ("Entre com o segundo numero: ");
scanf ("%f",&num2);
printf ("Entre com o terceiro numero: ");
scanf ("%f",&num3);
printf ("Entre com o quarto numero: ");
scanf ("%f",&num4);
media=Media(num1, num2, num3, num4);
printf ("\n\nA media entre os numeros eh: %f\n",media);	
return 0;	
}

float Media (float a, float b, float c, float d) 
{
return ((a+b+c+d)/4);	
}
