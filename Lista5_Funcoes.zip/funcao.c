#include <stdio.h>

int Square (int a)
{
 return (a*a);
}

int Cubo (int b)
{
 return (b*b*b);
}
