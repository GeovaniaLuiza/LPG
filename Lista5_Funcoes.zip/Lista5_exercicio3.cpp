/**3. Leia 3 n�meros, crie uma fun��o para calcular e retornar a soma dos
n�meros e outra fun��o para encontrar e imprimir o maior n�mero. **/

#include <stdio.h>

int Soma (int a, int b, int c);
int MaiorNum (int x, int y, int z);

int main () {
int num1, num2, num3;
int soma, maiorNum;
printf ("Entre com o primeiro numero: ");
scanf ("%d",&num1);
printf ("Entre com o segundo numero: ");
scanf ("%d",&num2);
printf ("Entre com o terceiro numero: ");
scanf ("%d",&num3);
soma= Soma (num1,num2,num3);
printf ("\n\nA soma dos numeros eh: %d\n" ,soma);
maiorNum = MaiorNum(num1,num2,num3);
printf ("\n\nO maior numero eh: %d\n", maiorNum);
return 0;
}

int Soma (int a, int b, int c){
	return (a+b+c);
}

int MaiorNum (int x, int y, int z){
	 if (x>y && x>z) {
	 	return (x);
	 } else if (y>x && y>z){
	 	return (y);
	 } else{
	 	return (z);
	 }	
}

