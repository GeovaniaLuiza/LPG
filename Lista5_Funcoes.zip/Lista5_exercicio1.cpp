/**1. Fa�a um programa em C com uma fun��o para calcular o quadrado de um
n�mero e outra para calcular o cubo de um n�mero. O n�mero deve ser
passado com par�metro e o resultado retornado ao programa principal. **/

#include <stdio.h>
int Square (int a);
int Cubo (int b);

int main ()
{
 int num,square,cubo;
 printf ("Entre com um numero: ");
 scanf ("%d",&num);
 square=Square(num);
 cubo=Cubo(num);
 printf ("\n\nO seu quadrado vale: %d\n",square);
 printf ("\n\nO seu cubo vale: %d\n",cubo);
 return 0;
}

int Square (int a)
{
 return (a*a);
}

int Cubo (int b)
{
 return (b*b*b);
}
