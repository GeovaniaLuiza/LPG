#include <stdio.h>
#include "funcao.h"
int main ()
{
 int num,square,cubo;
 printf ("Entre com um numero: ");
 scanf ("%d",&num);
 square=Square(num);
 cubo=Cubo(num);
 printf ("\n\nO seu quadrado vale: %d\n",square);
 printf ("\n\nO seu cubo vale: %d\n",cubo);
 return 0;
}

