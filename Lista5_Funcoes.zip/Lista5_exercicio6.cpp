/**6. Escreva um programa que solicite dois n�meros inteiros do usu�rio e mostre um menu com as op��es de opera��es 
aritm�ticas a serem feitas com estes dois valores: - produto - soma - diferen�a - divis�o - sa�da
Os c�lculos devem ser feitos dentro de quatro diferentes fun��es e os resultados devem ser impressos no programa principal. 
Use o comando switch no programa principal. As fun��es devem ser escritas abaixo do programa principal. Ap�s mostrar o 
resultado, o menu dever� reaparecer de forma que o usu�rio possa escolher outra op��o de opera��o. O encerramento do 
programa se dar� quando o usu�rio escolher a op��o de sa�da.**/

#include <stdio.h>

float Produto (float p1, float p2);
float Soma (float s1, float s2);
float Diferenca (float d1, float d2);
float Divisao (float div1, float div2);

int main () {
float num1=0, num2=0;
int opcao1=0;
float produto=0,soma=0,diferenca=0,divisao=0;
printf ("Entre com o primeiro numero: ");
scanf ("%f",&num1);
printf ("Entre com o segundo numero: ");
scanf ("%f",&num2);
produto = Produto (num1, num2);
soma = Soma (num1, num2);
diferenca = Diferenca (num1, num2);
divisao = Divisao (num1, num2);
do
   {
       printf("\n MENU PRINCIPAL\n");
       printf("\n  1. Produto\n");
       printf("\n  2. Soma\n");
       printf("\n  3. Diferenca\n");
       printf("\n  4. Divisao\n");
       printf("\n  0. Sair\n");
       printf("\n Selecione a opcao desejada: ");
       scanf("%d", &opcao1);
     } while ((opcao1 < 0) || (opcao1 >= 4));
     
	switch (opcao1) 
	{
		case 1:
			printf ("O produto dos numeros eh: %f",produto);
			break;	
		case 2:
			printf ("A soma dos numeros eh: %f",soma);
			break;	
		case 3:
			printf ("A diferenca dos numeros eh: %f",diferenca);	
			break;
		case 4:
			printf ("A divisao dos numeros eh: %f", divisao);
			break;
		default :
       		printf ("Saida\n");
	}
	return (opcao1);
}
float Produto (float p1, float p2){
	return (p1*p2);
}
float Soma (float s1, float s2){
	return (s1+s2);
}
float Diferenca (float d1, float d2){
	return (d1-d2);
}
float Divisao (float div1, float div2){
	return (div1/div2);
}


