
#include <stdio.h>
int Square (int a);
int Cubo (int b);


